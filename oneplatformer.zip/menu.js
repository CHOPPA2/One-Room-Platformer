var Menu = {
  preload() {
  game.load.image('menu', 'assets/menu.png');
  },
  create() {
  this.add.button(75, 0, 'menu', startGame);
  function startGame() {
    game.state.start('Game');
    }
  }
}
