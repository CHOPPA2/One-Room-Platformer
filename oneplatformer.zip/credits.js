var Credits = {
  preload() {
    game.load.audio('Your Reality', 'assets/ddlc.mp3');
    game.load.image('console', 'assets/console.png');
  },
  create() {
    var playText;
    var yourReality = this.add.audio('Your Reality', 1, false);
    let consol = this.add.image(0, 0, 'console');
    consol.scale.setTo(0.4, 0.7);
    consol.alpha = 0.4;
    var consoleText = this.add.text(50, 200, ">renpy.music.play('ddlc.ogg')", {fontSize: "16px", fill:"#fff"});
    consoleText.alpha = 0.7;
    setTimeout(nextText, 5000, reality);
    function nextText(callback) {
      consoleText.y = 150;
      playText = game.add.text(50, 170, "Playing audio 'ddlc.ogg'...", {fontSize: "16px", fill:"#fff"});
      setTimeout(callback, 3000);
    }
    function reality() {
    consol.kill();
    consoleText.kill();
    playText.kill();
    yourReality.play();
    }
  }
}
