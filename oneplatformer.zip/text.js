var monikaDialogue = [
  "Hi, it's me",
  "Uhmmmm",
  "So you know how I've been like",
  "practicing piano and stuff",
  "and not really any good at it yet,",
  "like at all...",
  "Butttt",
  "I wrote you a song",
  "and I was kinda hoping I could show it to you",
  "because I worked really, really hard on it",
  "Soooo",
  "yeah!"
]
